# Atualizar o WiEstoque no PC da empresa (sem Docker)

Use o arquivo atualizacao-edicao-materiais.zip. Ele contém a atualização do código, não o banco de dados nem as configurações locais da empresa. Não é necessário reinstalar o sistema.

1. Leve o ZIP ao PC da empresa por pendrive ou outro meio de transferência.
2. Termine as movimentações em andamento e execute o backup completo do banco pelo procedimento que já funciona lá. Confira se o arquivo foi criado e guarde uma cópia fora da pasta do sistema.
3. Pare o backend e o frontend: pressione Ctrl+C nas respectivas janelas. Mantenha o PostgreSQL em execução.
4. Faça também uma cópia da pasta da instalação atual, para guardar o código e as configurações anteriores. Essa cópia não substitui o backup do banco.
5. Clique com o botão direito no ZIP e escolha Extrair tudo. Extraia em uma pasta temporária, diferente da instalação atual.
6. Copie o conteúdo da pasta backend extraída para a pasta backend da instalação atual. Faça o mesmo com frontend. Escolha substituir os arquivos correspondentes. Copie por cima: não apague as pastas existentes.
7. Preserve application.properties, configuracao-local.ps1, os scripts/atalhos de início e as configurações locais. O pacote não contém application.properties. Não importe dados iniciais nem use scripts de instalação/reset do banco.
8. Abra um terminal na pasta frontend da instalação atual e execute:

   ```powershell
   npm install
   ```

   Aguarde a conclusão. Esta etapa precisa de internet para baixar as dependências e é necessária mesmo que node_modules já exista.
9. Inicie o backend e o frontend pelos scripts ou atalhos que já funcionam na empresa. Aguarde o backend concluir a inicialização; a compilação também pode precisar de internet para dependências novas. As migrações pendentes são aplicadas automaticamente pelo Flyway.
10. Abra o endereço que já utiliza e pressione Ctrl+F5 para atualizar a página.

## Conferir depois de atualizar

- O painel inicial deve aparecer com os dados reais já cadastrados.
- Confira saldos, técnicos, roteadores e movimentações anteriores.
- Confira os filtros de roteadores, a paginação, o botão Editar dos materiais e a exportação Excel.
- Em Devolução, selecione um técnico e confira os roteadores relacionados à última saída registrada.
- Materiais arquivados e técnicos inativos devem oferecer Reativar, quando existirem.

## Se aparecer um erro

Guarde a mensagem da janela do backend/frontend e não faça novas movimentações até resolver. Se a migração V6 indicar nomes duplicados de materiais, ela interrompe a atualização sem mesclar ou apagar cadastros. Não apague ou renumere migrações para contornar esse erro.

Como podem existir migrações pendentes de atualizações anteriores, voltar apenas os arquivos antigos pode não ser suficiente para reverter a atualização. Guarde a cópia da instalação e o backup completo do banco para uma recuperação coordenada, se necessária.

Esta atualização foi testada neste computador. Ela ainda precisa ser aplicada e conferida no PC da empresa.
